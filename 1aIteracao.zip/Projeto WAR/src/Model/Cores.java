package Model;

// cores disponiveis
enum Cores {
	AZUL, VERMELHO, VERDE, BRANCO, PRETO, AMARELO
}
