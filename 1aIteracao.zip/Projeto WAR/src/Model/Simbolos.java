package Model;

enum Simbolos {
	TRIANGULO, QUADRADO, CIRCULO, CORINGA
};