package Model;

enum Simbolos {
	/** Simbolos das cartas de territorio. */
	TRIANGULO, QUADRADO, CIRCULO, CORINGA
};