package Model;

enum Cores {
	/** Cores disponiveis para os jogadores da partida */
	AZUL, VERMELHO, VERDE, BRANCO, PRETO, AMARELO
}
