package Observer;

public interface ObservadorIF {
	public void notify(ObservadoIF o);
}
